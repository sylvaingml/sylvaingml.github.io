// Singleton with a structure

import Foundation

struct MySingleton
{
    // Counter to tag each new instance
    private static var count: Int = 0
    
    // Our singleton, as returned by sharedInstance()
    private static var instance : MySingleton?
    
    // Instance identifier
    var id: Int
    
    init()
    {
        id = MySingleton.count++
    }
    
    // Access the shared instance, only create one
    static func sharedInstance() -> MySingleton
    {
        instance = instance ?? MySingleton()
        return instance!
    }
}


// Shall return the object owith 1st id (0)
MySingleton.sharedInstance()

// In real singleton init() shall be made private
// Just made it public to show behavior
//
MySingleton()
MySingleton()
MySingleton()

// Check that returned instance is still the same object
MySingleton.sharedInstance()

